# Sqlite_Crud_AndroidStudio
Simple crud using sqlite database android studio
#
![VIEW](https://user-images.githubusercontent.com/46634156/75051980-6c635980-5501-11ea-9741-21fa4147aeb2.png)
