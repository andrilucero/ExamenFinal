package com.example.sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DataBaseHelper myDb;
    Button btnClick, btnRead, btnDelete, btnUpdate;
    EditText txtNombre, txtApellido, txtTelefono, txtId;
    TextView txtResultados;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myDb = new DataBaseHelper(this);
        txtTelefono = findViewById(R.id.idMark);
        txtApellido = findViewById(R.id.idSurname);
        txtNombre = findViewById(R.id.idName);
        btnClick = findViewById(R.id.idBtn);
        btnRead = findViewById(R.id.idBtnRead);
        txtResultados = findViewById(R.id.idResult);
        txtId = findViewById(R.id.idID);
        btnDelete = findViewById(R.id.idHapus);
        btnUpdate = findViewById(R.id.idUpdate);

        btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClickMe();
            }
        });

        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ReadMe();
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteMe();
                ReadMe();
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UpdateMe();
            }
        });

    }


    ///Update
    private void UpdateMe() {

        String id = txtId.getText().toString();
        String name = txtNombre.getText().toString();
        String surname = txtApellido.getText().toString();
        String mark = txtTelefono.getText().toString();
    Boolean result = myDb.uodateData(id, name, surname, mark);
    if (result == true)
    {
        Toast.makeText(this, "Data Update Success", Toast.LENGTH_SHORT).show();
    }
    else
    {
        Toast.makeText(this, "Data Update Failed", Toast.LENGTH_SHORT).show();
    }

    }


    /// Delete
    private void DeleteMe() {

        String id = txtId.getText().toString();
        int result = myDb.deleteData(id);
        Toast.makeText(this, result + ":Row Affected", Toast.LENGTH_SHORT).show();

    }

    private void ReadMe() {

        Cursor res = myDb.getAllData();
        StringBuffer stringBuffer = new StringBuffer();
        if (res != null && res.getCount() > 0) {
            while (res.moveToNext()) {
                stringBuffer.append("Id :" + res.getString(0) + "\n");
                stringBuffer.append("Nombre :" + res.getString(1) + "\n");
                stringBuffer.append("Apellido :" + res.getString(2) + "\n");
                stringBuffer.append("Telefono :" + res.getString(3) + "\n");
            }

            txtResultados.setText(stringBuffer.toString());
            Toast.makeText(this, "Data Retrieved Succesfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Data Retrieved Failed", Toast.LENGTH_SHORT).show();
        }


    }

    private void ClickMe() {

        String name = txtNombre.getText().toString();
        String surname = txtApellido.getText().toString();
        String mark = txtTelefono.getText().toString();
        Boolean result = myDb.insertData(name, surname, mark);

        if (result == true) {
            Toast.makeText(this, "Data Inserted Succesfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Data Inserted Failed", Toast.LENGTH_SHORT).show();

        }
    }
}
